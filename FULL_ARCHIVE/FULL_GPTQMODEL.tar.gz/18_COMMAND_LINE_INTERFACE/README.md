# 18 Command Line Interface

**Project:** GPTQMODEL
**Upstream:** https://github.com/ModelCloud/GPTQModel

Content specific to GPTQMODEL in category CHIP_QUANTIZATION.
